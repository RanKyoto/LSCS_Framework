class L2_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  x_stable : Tensor
  f_hat : __torch__.torch.nn.modules.container.Sequential
  lyapunov_function : __torch__.networks.LyapunovFunction
  alpha_hat : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  def forward(self: __torch__.models.L2_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    _0 = (f_hat).forward(x, )
    f_hat0 = self.f_hat
    x_stable = self.x_stable
    _1 = torch.sub(_0, (f_hat0).forward(x_stable, ))
    f0 = torch.unsqueeze(_1, 2)
    alpha_hat = self.alpha_hat
    _2 = (alpha_hat).forward(x, )
    alpha_hat0 = self.alpha_hat
    x_stable0 = self.x_stable
    _3 = torch.sub(_2, (alpha_hat0).forward(x_stable0, ))
    alpha = torch.unsqueeze(_3, 2)
    _4 = [0., 1.]
    device = self.device
    _5 = torch.tensor(_4, dtype=6, device=device)
    g = torch.reshape(_5, [1, 2, 1])
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(x, )
    torch.autograd.backward(torch.sum(V))
    grad_V = torch.unsqueeze(ops.prim.grad(x), 2)
    _6 = torch.pow(torch.select(torch.slice(x), 1, 0), 2)
    _7 = torch.reshape(_6, [-1, 1, 1])
    _8 = torch.select(torch.slice(grad_V), 1, 1)
    _9 = torch.reshape(torch.pow(torch.slice(_8, 1), 2), [-1, 1, 1])
    W = torch.add(_7, _9)
    _10 = torch.transpose(grad_V, 1, 2)
    _11 = torch.add(f0, torch.matmul(g, alpha))
    criterion = torch.add(torch.matmul(_10, _11), torch.mul(W, 0.01))
    _12 = torch.neg(criterion)
    _13 = torch.sum(torch.pow(grad_V, 2), [1], True)
    _14 = torch.add(_13, 9.9999999999999995e-07)
    fs = torch.mul(torch.div(_12, _14), grad_V)
    mask = torch.le(criterion, 0)
    f = torch.where(mask, f0, torch.add(f0, fs))
    return (f, g, alpha, V)
