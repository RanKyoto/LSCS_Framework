class Safty_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  c4 : float
  f_hat : __torch__.torch.nn.modules.container.Sequential
  alpha : __torch__.torch.nn.modules.container.___torch_mangle_3.Sequential
  g : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.models.Safty_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    f_hat0 = torch.unsqueeze((f_hat).forward(x, ), 2)
    alpha = self.alpha
    alpha0 = torch.unsqueeze((alpha).forward(x, ), 2)
    _0 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _1 = (_00).forward(x, )
    state_dim = self.state_dim
    _2 = torch.reshape(_1, [-1, state_dim, 1])
    _3 = torch.append(_0, _2)
    g0 = torch.squeeze(torch.stack(_0, 2), 3)
    eta = torch.reshape(__torch__.eta(x, ), [-1, 1, 1])
    torch.autograd.backward(torch.sum(eta), None, True)
    grad_eta = torch.unsqueeze(ops.prim.grad(x), 2)
    _4 = torch.transpose(grad_eta, 1, 2)
    _5 = torch.add(f_hat0, torch.matmul(g0, alpha0))
    _6 = torch.matmul(_4, _5)
    c4 = self.c4
    criterion = torch.add(_6, torch.mul(eta, c4))
    _7 = torch.neg(criterion)
    _8 = torch.sum(torch.pow(grad_eta, 2), [1], True)
    _9 = torch.add(_8, 9.9999999999999995e-07)
    f_eta = torch.mul(torch.div(_7, _9), grad_eta)
    mask = torch.le(criterion, 0)
    f = torch.where(mask, f_hat0, torch.add(f_hat0, f_eta))
    return (f, g0, alpha0, eta)
