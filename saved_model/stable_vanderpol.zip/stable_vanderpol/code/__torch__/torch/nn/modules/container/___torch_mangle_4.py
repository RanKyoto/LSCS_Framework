class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  __annotations__["0"] = __torch__.networks.posLinear
  __annotations__["1"] = __torch__.networks.___torch_mangle_3.posLinear
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_4.ModuleList) -> int:
    return 2
