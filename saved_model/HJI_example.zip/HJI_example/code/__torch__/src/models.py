class HJI_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  alpha_hat : NoneType
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  x_stable : Tensor
  f_hat : __torch__.torch.nn.modules.container.Sequential
  lyapunov_function : __torch__.src.networks.LyapunovFunction
  g : __torch__.torch.nn.modules.container.___torch_mangle_6.ModuleList
  def forward(self: __torch__.src.models.HJI_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    _0 = (f_hat).forward(x, )
    f_hat0 = self.f_hat
    x_stable = self.x_stable
    _1 = torch.sub(_0, (f_hat0).forward(x_stable, ))
    f0 = torch.unsqueeze(_1, 2)
    _2 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _3 = (_00).forward(x, )
    state_dim = self.state_dim
    _4 = torch.reshape(_3, [-1, state_dim, 1])
    _5 = torch.append(_2, _4)
    g0 = torch.squeeze(torch.stack(_2, 2), 3)
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(x, )
    _6 = torch.autograd.grad([torch.sum(V)], [x], None, None, True)
    grad_V = _6[0]
    if torch.__isnot__(grad_V, None):
      grad_V1 = unchecked_cast(Tensor, grad_V)
      grad_V2 = torch.reshape(grad_V1, [-1, 1, 1])
      grad_V0 = grad_V2
    else:
      device = self.device
      grad_V3 = torch.zeros_like(x, dtype=6, layout=None, device=device)
      grad_V0 = grad_V3
    LgV = torch.matmul(grad_V0, g0)
    alpha = torch.neg(LgV)
    W = torch.add(torch.unsqueeze(torch.pow(x, 2), 2), torch.mul(torch.pow(LgV, 2), 0.5))
    _7 = torch.add(f0, torch.matmul(g0, alpha))
    _8 = torch.add(torch.matmul(grad_V0, _7), W)
    _9 = torch.sum(torch.pow(grad_V0, 2), [1], True)
    _10 = torch.div(_8, torch.add(_9, 0.0001))
    criterion = torch.relu(_10)
    fs = torch.mul(torch.neg(criterion), grad_V0)
    f = torch.add(f0, fs)
    _11 = torch.transpose(grad_V0, 1, 2)
    _12 = torch.add(f, torch.matmul(g0, alpha))
    H = torch.add(torch.matmul(_11, _12), W)
    return (f, g0, alpha, V, H)
